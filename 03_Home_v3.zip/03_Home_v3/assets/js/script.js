jQuery(document).ready(function(){
	jQuery('.mobile-icon').on('click', function(){
		jQuery('.menu').toggle();
	});
	jQuery(window).resize(function(){
		var scren_size = jQuery(window).width();
		if (scren_size > 768) {
			jQuery('.menu').show();
		}
	});
});